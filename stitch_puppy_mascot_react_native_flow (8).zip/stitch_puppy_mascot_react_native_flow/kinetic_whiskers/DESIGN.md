---
name: Kinetic Whiskers
colors:
  surface: '#faf8ff'
  surface-dim: '#d9d9e2'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3fb'
  surface-container: '#ededf6'
  surface-container-high: '#e7e7f0'
  surface-container-highest: '#e2e2ea'
  on-surface: '#191b21'
  on-surface-variant: '#434656'
  inverse-surface: '#2e3037'
  inverse-on-surface: '#f0f0f9'
  outline: '#737687'
  outline-variant: '#c3c5d8'
  surface-tint: '#004ee8'
  primary: '#0049db'
  on-primary: '#ffffff'
  primary-container: '#2962ff'
  on-primary-container: '#f7f5ff'
  inverse-primary: '#b6c4ff'
  secondary: '#ae3115'
  on-secondary: '#ffffff'
  secondary-container: '#fd6a49'
  on-secondary-container: '#640f00'
  tertiary: '#7b4f00'
  on-tertiary: '#ffffff'
  tertiary-container: '#9b6500'
  on-tertiary-container: '#fff4eb'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#b6c4ff'
  on-primary-fixed: '#001550'
  on-primary-fixed-variant: '#003ab3'
  secondary-fixed: '#ffdad2'
  secondary-fixed-dim: '#ffb4a3'
  on-secondary-fixed: '#3d0600'
  on-secondary-fixed-variant: '#8c1900'
  tertiary-fixed: '#ffddb4'
  tertiary-fixed-dim: '#ffb955'
  on-tertiary-fixed: '#291800'
  on-tertiary-fixed-variant: '#633f00'
  background: '#faf8ff'
  on-background: '#191b21'
  surface-variant: '#e2e2ea'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '800'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.015em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-sm: 0.75rem
  gutter-lg: 1.5rem
  margin: 1.25rem
  margin-mobile: 1rem
  margin-tablet: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system expresses attentive, joyful, and deeply trustworthy care for pets and their companions. Combining modern clarity with soft physical warmth, it steers clear of clinical sterility and childish excess. The voice balances veterinary precision with the comforting touch of home life.

Visual characteristics center on tactile softness, inviting organic geometry, and buoyant contrast:
- **Style Archetype:** Soft modernism with warm domestic undertones. Generous white space, pillular forms, and micro-delights through playful ambient accents.
- **Tone:** Empathetic, dependable, uplifting, intuitive.
- **Key Motifs:** Oversized corner radii, pill buttons, floating card planes over creamy ivory backdrops, and targeted bursts of coral and amber to celebrate pet milestones.

## Colors

The palette pairs an authoritative, electric cobalt with warm culinary and domestic tones, anchoring daily pet routines in optimism and structure.

### Palette Architecture
- **Primary Brand Cobalt (`#2962FF`):** Powers key actions, focus indicators, active tab bars, tracking meters, and clinical confirmations.
- **Soft Cobalt Wash (`#E8F0FE`):** Backdrops for selected state tags, secondary chips, active list tiles, and circular progress tracks.
- **Secondary Coral (`#FF6B4A`):** Critical alerts, urgent vaccination counters, active streak marks, and high-priority contextual actions.
- **Tertiary Amber (`#FFB340`):** Feeding reminders, daily achievement medals, playful status updates, and warm spotlight tags.
- **Surface Peach Wash (`#FFF3E8`):** Pet mascot stages, greeting header banners, and empty-state illustrations.
- **Main Canvas Ivory (`#FFFDF9`):** Replaces clinical stark white on screen foundations, delivering eye comfort across extended browsing sessions.
- **Card Neutral Surface (`#FFFFFF`):** High-clarity elevated planes hosting data and actionable items.
- **Text Headings (`#181A20`):** Deep navy-black providing high-legibility contrast.
- **Text Subtitles & Labels (`#757B8A`):** Cool slate grey for contextual meta tags, inactive states, and input field labels.
- **Dividers & Subtle Borders (`#EFEFEF`):** Passive boundaries between dense content sets.

## Typography

Typographic scale is constructed entirely using **Plus Jakarta Sans**, utilizing its geometric clarity, friendly counters, and rounded terminals.

- **Display & Large Headlines:** Used for pet profile introductions, dashboard greetings, and celebratory streak popovers. Generous weight prevents thin hairline rendering on outdoor screens.
- **Body Hierarchy:** Renders clinical details, care regimens, and feeding metrics with high legibility.
- **Micro Labels:** Set in semibold and bold with deliberate positive tracking (`0.01em` to `0.04em`) to ensure quick scanning of medication badges, timestamps, and dietary status indicators.

## Layout & Spacing

A strictly mobile-first layout based on an 8pt spatial grid anchors the mobile application shell.

### Grid & Margins
- **Canvas Columns:** 4 columns on standard mobile screens (`<600px`), expanding to 8 columns on tablets and foldables (`601px - 1024px`).
- **Outer Margins:** `1.25rem` (20px) baseline on mobile to afford edge thumb clearance, shrinking to `1rem` (16px) on compact handhelds, and scaling to `2rem` (32px) on tablets.
- **Inner Column Gutters:** `1rem` (16px) standard spacing between content blocks and parallel stat cards.

### Content Spacing
- Internal card padding is locked to `1.25rem` (20px) or `1.5rem` (24px) for full-width cards.
- Vertical section spacing observes `2rem` (32px) to prevent visual crowding between disparate daily tracking modules (e.g., diet timeline vs. vet records).

## Elevation & Depth

Visual hierarchy uses physical-plane separation rather than heavy line work or harsh drop shadows.

- **Canvas Foundation:** `#FFFDF9` Warm Ivory rests at the lowest ground layer (Elevation 0).
- **Floating Sheet (Elevation 1):** Main cards and actionable lists cast an ambient drop shadow: `0 12px 32px rgba(24, 26, 32, 0.06)`. This diffused, un-tinted shadow makes white containers float organically above the ivory canvas.
- **Raised Elements & Floating Action Menus (Elevation 2):** Primary bottom navigation bars and floating quick-log modals use `0 16px 40px rgba(41, 98, 255, 0.12)`, integrating a soft blue ambient glow.
- **Top Sheets & Toasts (Elevation 3):** Urgent notices, alert banners, and active modal overlays cast `0 20px 48px rgba(24, 26, 32, 0.16)`.
- **Borders:** Structural cards carry no outer borders; only selected or interactive states introduce a 1.5px `#2962FF` or `#EFEFEF` boundary.

## Shapes

The design system embraces an ultra-rounded shape identity (Level 3), reinforcing playfulness, safe handling, and ergonomic mobile reach.

- **Primary Buttons & Action Bars:** Full pill geometry (`border-radius: 999px`).
- **Core Cards & Containers:** Standardized `border-radius: 24px`.
- **Chips, Pill Tags & Input Fields:** Rounded full (`border-radius: 999px`) or soft capsule (`border-radius: 16px` for multi-line inputs).
- **Avatars & Pet Mascot Rings:** Perfect circular geometry (`50%` radius) complemented by pill badge overlays for status alerts.

## Components

### Buttons
- **Primary Action Button:** Height of 56px, fully pill-shaped (`border-radius: 999px`), solid `#2962FF` background, `#FFFFFF` text (Label LG, 600 weight). Pressed state transitions to `#1E4BD8`.
- **Secondary / Accent Action Button:** Height of 56px, `#FF6B4A` background with `#FFFFFF` text, reserved for critical pet actions (e.g., "Log Incident", "Emergency SOS").
- **Subtle / Neutral Button:** Height of 56px, `#E8F0FE` background with `#2962FF` typography.
- **Icon Buttons:** 48px × 48px or 56px × 56px circular bounds (`border-radius: 50%`) with centered 24px iconography.

### Cards
- **Base Card:** Pristine `#FFFFFF` surface, `border-radius: 24px`, ambient shadow `0 12px 32px rgba(24, 26, 32, 0.06)`, internal padding `1.25rem` (20px).
- **Selected Pet / Metric Card:** Surface transitions to `#FFFFFF` with an active `2px` stroke in `#2962FF` and an interior indicator wash in `#E8F0FE`.
- **Spotlight / Mascot Banner Card:** Background set to `#FFF3E8`, containing soft amber and coral graphics, with no ambient shadow, creating a flat canvas contrast.

### Chips & Filter Pills
- **Base State:** Height 36px, `border-radius: 999px`, `#FFFFFF` background, 1px border `#EFEFEF`, text `#757B8A` (Label MD).
- **Active State:** Background `#E8F0FE`, border `#2962FF`, text `#2962FF`.
- **Metric Pill:** Background `#FFF3E8`, text `#FF6B4A`, often containing an icon prefix for quick glanceable telemetry (e.g., caloric intake, step counters).

### Lists & Activity Tiles
- **Tile Architecture:** Floating white row cards (`border-radius: 16px`) with 12px vertical gaps, rather than continuous bordered lines.
- **Item Format:** Left slot contains a 44px circular icon container (tinted with `#E8F0FE` or `#FFF3E8`), center slot houses Title (`#181A20`, Headline SM) and Subtitle (`#757B8A`, Body SM), right slot reserves room for status badges or time markers.

### Input Fields
- **Container:** Height 56px, fully pill-shaped (`border-radius: 999px`), surface `#FFFFFF`, 1.5px border `#EFEFEF`.
- **Focus State:** 2px border `#2962FF` with zero ambient halo.
- **Typography:** `#181A20` input value, `#757B8A` placeholder. Left and right padding set to 24px.

### Checkboxes & Radio Controls
- **Radio Buttons:** 24px × 24px circular ring. Unchecked has a 2px `#EFEFEF` rim. Checked fills with `#2962FF` featuring a 10px centered white disc.
- **Checkboxes:** 24px × 24px square container with `border-radius: 8px`. Checked fills with `#2962FF` containing a crisp white tick mark.

### Specialized Pet Care Components
- **Progress Tracking Rings:** Circular rings utilizing `#2962FF` for completed stages, backed by an inactive rail of `#E8F0FE`, with centered milestone values in `#181A20`.
- **Streak & Milestone Badge:** Pill capsule using `#FF6B4A` background, white label typography, and an animated micro-sparkle indicator in `#FFB340`.